import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useEffect, useRef, useState } from 'react';
import { Button, TouchableOpacity } from 'react-native';
import { View, Text, StyleSheet, ScrollView, ImageBackground, Image } from 'react-native';

const Resume = ({navigation}) => {
  const [resumeData, setResumeData] = useState(null);
  useEffect(()=>{
    GetData();
  },[])
  const GetData = async () => {
    try {
      // Retrieve data from AsyncStorage
      const storedData = await AsyncStorage.getItem('profileData');
  
      if (storedData !== null) {
        const parsedData = JSON.parse(storedData);
        console.log('Retrieved data:', parsedData);
        setResumeData(parsedData)
        console.log(resumeData.name);
        return parsedData;
      } else {
        console.log('No data found in AsyncStorage');
        return null;
      }
    } catch (error) {
      console.error('Error retrieving data from AsyncStorage:', error);
      return null;
    }
  };
  
  const pdfRef = useRef();

  const generatePDF = async () => {
    alert("Your Pdf will stored on the path of Android/data/com.myapp/files/document")
    const htmlContent = generateHTML(resumeData);

    const options = {
      html: htmlContent,
      fileName: 'samplePDF',
      directory: 'Documents',
    };
    const generateHTML = (item) => (
      `
      <html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-color: #D3D3D3;
    }

    .background-image {
      background-image: url('https://placekitten.com/300/600');
      background-size: cover;
      background-position: center;
      height: 100vh; /* Full height of the viewport */
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .content {
      background-color: rgba(255, 255, 255, 0.9);
      padding: 20px;
      border-radius: 10px;
      margin: 20px;
      width: 80%;
    }

    .header {
      display: flex;
      align-items: center;
      margin-bottom: 20px;
    }

    .profile-image {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      margin-right: 20px;
    }

    .name {
      font-size: 24px;
      font-weight: bold;
    }

    .section {
      margin-bottom: 20px;
    }

    .label {
      font-size: 18px;
      margin-bottom: 5px;
      font-weight: bold;
    }

    .text {
      font-size: 16px;
    }
  </style>
</head>
<body>
  <div class="background-image">
    <div class="content">
      <div class="header">
        <img class="profile-image" src="https://placekitten.com/200/200" alt="Profile Image">
        <div class="name">${item.name}</div>
      </div>

      <div class="section">s
        <div class="label">Date of Birth:</div>
        <div class="text">${item.dob}</div>
      </div>

      <div class="section">
        <div class="label">Email:</div>
        <div class="text">${item.email}</div>
      </div>

      <div class="section">
        <div class="label">Phone:</div>
        <div class="text">${item.phone}</div>
      </div>

      <div class="section">
        <div class="label">Education:</div>
        <div class="text">${item.study}</div>
      </div>

      <div class="section">
        <div class="label">Skills:</div>
        <div class="text">${item.skills}</div>
      </div>

      <div class="section">
        <div class="label">Experience:</div>
        <div class="text">${item.experience}</div>
      </div>

      <div class="section">
        <div class="label">Website:</div>
        <div class="text">${item.website}</div>
      </div>
    </div>
  </div>
</body>
</html>`
    );
    try {
      const file = await RNHTMLtoPDF.convert(options);
      console.log(file.filePath);
      // Now, file.filePath contains the path to the generated PDF file.
    } catch (error) {
      console.error('Error generating PDF:', error);
    }
  };
  return (
    <ScrollView style={styles.container}>
      <ImageBackground
        source={{ uri: 'https://placekitten.com/300/600' }} // Replace with your border image URL
        style={styles.backgroundImage}
      >
        <View style={styles.content}>
          <View style={styles.header}>
            <Image
              source={{ uri: 'https://placekitten.com/200/200' }} // Replace with your profile image URL
              style={styles.profileImage}
            />
            <Text style={styles.name}>{resumeData.name}</Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.label}>Date of Birth:</Text>
            <Text style={styles.text}>{resumeData.dob}</Text>
          </View>
          <View style={styles.section}>
            <Text style={styles.label}>Email:</Text>
            <Text style={styles.text}>{resumeData.email}</Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.label}>Phone:</Text>
            <Text style={styles.text}>{resumeData.phone}</Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.label}>Education:</Text>
            <Text style={styles.text}>{resumeData.study}</Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.label}>Skills:</Text>
            <Text style={styles.text}>{resumeData.skills}</Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.label}>Experience:</Text>
            <Text style={styles.text}>{resumeData.experience}</Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.label}>Website:</Text>
            <Text style={styles.text}>{resumeData.website}</Text>
          </View>

        </View>
      </ImageBackground>

      <View style={styles.buttonsContainer}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.navigate("Home")}>
          <Text style={styles.backButtonText}>Back to Home</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.downloadButton} onPress={generatePDF}>
          <Text style={styles.downloadButtonText}>Download In PDF</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#D3D3D3"
  },
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
    height: '100%', // Cover the full height of the screen
  },
  content: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)', // Background color to make text readable
    padding: 20,
    borderRadius: 10,
    margin: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginRight: 20,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    letterSpacing:2
  },
  section: {
    marginBottom: 20,
  },
  label: {
    fontSize: 18,
    marginBottom: 5,
    fontWeight: 'bold',
  },
  text: {
    fontSize: 16,
  }, buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },

  backButton: {
    backgroundColor: '#6495ED',
    padding: 15,
    borderRadius: 10,
    flex: 1,
    marginRight: 10,
  },

  backButtonText: {
    textAlign: 'center',
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    letterSpacing: 1,
  },

  downloadButton: {
    backgroundColor: '#FF6347',
    padding: 15,
    borderRadius: 10,
    flex: 1,
    marginLeft: 10,
  },

  downloadButtonText: {
    textAlign: 'center',
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
});

export default Resume;
