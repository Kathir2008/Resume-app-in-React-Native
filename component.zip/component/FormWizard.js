import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const FormWizard = () => {
  const [formData, setFormData] = useState({
    step: 1,
    firstName: '',
    lastName: '',
    email: '',
  });

  const nextStep = () => {
    setFormData((prevData) => ({ ...prevData, step: prevData.step + 1 }));
  };

  const prevStep = () => {
    setFormData((prevData) => ({ ...prevData, step: prevData.step - 1 }));
  };

  const handleChange = (name, value) => {
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const renderStep = () => {
    const { step, firstName, lastName, email } = formData;

    switch (step) {
      case 1:
        return (
          <View style={styles.stepContainer}>
            <Text>Step 1</Text>
            <TextInput
              placeholder="First Name"
              value={firstName}
              onChangeText={(text) => handleChange('firstName', text)}
            />
            <Button title="Next" onPress={nextStep} />
          </View>
        );
      case 2:
        return (
          <View style={styles.stepContainer}>
            <Text>Step 2</Text>
            <TextInput
              placeholder="Last Name"
              value={lastName}
              onChangeText={(text) => handleChange('lastName', text)}
            />
            <Button title="Next" onPress={nextStep} />
            <Button title="Previous" onPress={prevStep} />
          </View>
        );
      case 3:
        return (
          <View style={styles.stepContainer}>
            <Text>Step 3</Text>
            <TextInput
              placeholder="Email"
              value={email}
              onChangeText={(text) => handleChange('email', text)}
            />
            <Button title="Submit" onPress={submitForm} />
            <Button title="Previous" onPress={prevStep} />
          </View>
        );
      default:
        return null;
    }
  };

  const submitForm = () => {
    // Implement form submission logic here
    console.log('Form submitted:', formData);
  };

  return <View style={styles.container}>{renderStep()}</View>;
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  stepContainer: {
    width: '80%',
  },
});

export default FormWizard;
