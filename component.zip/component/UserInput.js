import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useState } from "react";
import {ScrollView,View,Text,TextInput,TouchableOpacity,Image,StyleSheet,} from "react-native";
import ImagePicker from "react-native-image-crop-picker";

const UserInput = ({ navigation }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [image, setImage] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");

  // Personal Details
  const [name, setName] = useState("");
  const [dob, setDob] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [country, setCountry] = useState("");

  // Education and Skills
  const [study, setStudy] = useState("");
  const [skills, setSkills] = useState("");

  // websites and social links
  const [website, setWebsite] = useState("");
  const [linkedin, setLinkedin] = useState("");
  const [insta, setInsta] = useState("");

  // Professional Summary
  const [experience, setExperience] = useState("");
  const [summary, setSummary] = useState("");

  const handleImagePicker = async () => {
    try {
      const pickedImage = await ImagePicker.openPicker({
        width: 300,
        height: 400,
        cropping: true,
      });

      setImage({ uri: pickedImage.path });
    } catch (error) {
      console.log("Error picking image:", error);
    }
  };

  const saveDataToStorage = async (data) => {
    try {
      console.log("Saving data to AsyncStorage:", data);
      await AsyncStorage.setItem("profileData", JSON.stringify(data));
      console.log("Data saved successfully!");
    } catch (error) {
      console.error("Error saving data to AsyncStorage:", error);
    }
  };

  const getData = () => ({name,dob,phone,email,study,skills,website,insta,linkedin,summary,country,experience,image,});

  const handleNext = () => {
    if (currentStep < 4) {
      setErrorMessage("");
      if (
        currentStep === 1 &&
        (!name || !dob || !phone || !email || !country)
      ) {
        setErrorMessage("Validation Error: Fill out all required fields");
        
      } else if (currentStep === 2 && (!study || !skills)) {
        setErrorMessage("Validation Error: Fill out all required fields");
        
      } 
      else{
      setCurrentStep(currentStep + 1);
      }
    } else {
      const dataToSave = getData();
      saveDataToStorage({ ...dataToSave });
      console.log(saveDataToStorage);
      navigation.navigate("Resume");
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      setErrorMessage("");
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.container}>
        {/* Form Steps */}
        <View style={styles.formContainer}>
          {currentStep === 1 && (
            <View>
              <TouchableOpacity onPress={handleImagePicker}>
                {image ? (
                  <Image source={{ uri: image.uri }} style={styles.centeredImage} />
                ) : (
                  <View style={styles.centeredPlaceholder}>
                    <Text style={styles.placeholderText}>Select Image</Text>
                  </View>
                )}
              </TouchableOpacity>
              <Text style={styles.sectionTitle}>Personal Details</Text>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Name:</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your name"
                  value={name}
                  onChangeText={(text) => setName(text)}
                  required
                />
              </View>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Date of Birth:</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your Date of Birth"
                  value={dob}
                  onChangeText={(text) => setDob(text)}
                  required
                />
              </View>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Phone Number:</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your Phone Number"
                  value={phone}
                  onChangeText={(text) => setPhone(text)}
                  required
                />
              </View>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Email:</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your Email"
                  value={email}
                  onChangeText={(text) => setEmail(text)}
                  required
                />
              </View>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Country:</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your Country"
                  value={country}
                  onChangeText={(text) => setCountry(text)}
                  required
                />
              </View>
            </View>
          )}
          {currentStep === 2 && (
            <View>
              <Text style={styles.sectionTitle}>Education and Skills</Text>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Study:</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your study details"
                  value={study}
                  onChangeText={(text) => setStudy(text)}
                  required
                />
              </View>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Skills:</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your skills"
                  value={skills}
                  onChangeText={(text) => setSkills(text)}
                  required
                />
              </View>
            </View>
          )}
          {currentStep === 3 && (
            <View>
              <Text style={styles.sectionTitle}>Website and Social Links</Text>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Website:</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your Website Link"
                  value={website}
                  onChangeText={(text) => setWebsite(text)}
                />
              </View>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>LinkedIn:</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your LinkedIn link"
                  value={linkedin}
                  onChangeText={(text) => setLinkedin(text)}
                />
              </View>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Instagram:</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your Instagram id"
                  value={insta}
                  onChangeText={(text) => setInsta(text)}
                />
              </View>
            </View>
          )}
          {currentStep === 4 && (
            <View>
              <Text style={styles.sectionTitle}>Professional</Text>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Experience:</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your experience details"
                  value={experience}
                  onChangeText={(text) => setExperience(text)}
                />
              </View>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Professional Summary:</Text>
                <TextInput
                  multiline={true}
                  style={styles.inputArea}
                  numberOfLines={8}
                  onChangeText={(val) => setSummary(val)}
                  value={summary}
                />
              </View>
            </View>
          )}
          {errorMessage && (
            <Text style={styles.errorMessage}>{errorMessage}</Text>
          )}
          <View style={styles.buttonContainer}>
            {currentStep > 1 && (
              <TouchableOpacity style={styles.prevButton} onPress={handlePrev}>
                <Text style={styles.buttonText}>&laquo; Previous</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity style={styles.nextButton} onPress={handleNext}>
              <Text style={styles.buttonText}>
                {currentStep < 4 ? "Next" : "Submit"}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  container: {
    alignItems: "center",
    marginTop: 20,
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginVertical: 20,
  },
  errorMessage: {
    color: "red",
    marginBottom: 10,
  },
  placeholder: {
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: "#ddd",
    justifyContent: "center",
    alignItems: "center",
  },
  placeholderText: {
    fontSize: 16,
    color: "#5e72e4",
  },
  formContainer: {
    width: "80%",
    marginVertical: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10,
    textAlign: "center",
    color: "#555",
  },
  inputContainer: {
    marginBottom: 15,
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
    color: "#5e72e4",
  },
  input: {
    height: 40,
    borderColor: "#555",
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
  },
  saveButton: {
    backgroundColor: "#5e72e4",
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 25,
    marginTop: 20,
  },
  saveButtonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
  inputArea: {
    borderColor: "#5e72e4",
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    textAlignVertical: "top",
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
  },
  prevButton: {
    backgroundColor: "#5e72e4",
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 25,
  },
  nextButton: {
    backgroundColor: "#5e72e4",
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 25,
  },
  buttonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
  centeredImage: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginVertical: 20,
    alignSelf: 'center',
  },
  centeredPlaceholder: {
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: "#ddd",
    justifyContent: "center",
    alignItems: "center",
    alignSelf: 'center',
  },
});

export default UserInput;